/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


$(document).ready(function(){
                    
        //hide the show message at first
        $('#group').hide();
        $('#hide').hide();
        $('body').css('background', 'greenyellow');

        //Turn UI pink 
        $('#group').on('mouseleave',function(){
            $('body').css('background','pink');
        });
                    
        //Turn UI red
        $('#group').on('mouseenter', function(){
            $('body').css('background','red'); 
        });
                    
        //show UI
        $('#show').click(function(){
            $('#group').show();
            $('#hide').show();
            $('#show').hide();
        });
                    
        //hide UI
        $('#hide').click(function(){
            $('#group').hide();
            $('#show').show ();
            $('#hide').hide();
            $('body').css('background', 'greenyellow');
        });
        
        
        $('#yes').click(function(){
           $('body').css('background','orange'); 
        });
        
        //submit user info via ajax
        $('#btn').click(function(){
            //pull vars 
            var username = $('#username').val();
            var password = $('#password').val();
            
            //request for username
            $.post("php.php", {user:username,pass:password}).done(function(data){
                $("#loginMessage").html(data);
            }); 
           
        });
});         