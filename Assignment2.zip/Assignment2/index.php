<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<!-- Note to professor Username = Admin, Password: 1234-->
<html>
    <head>
        <title>MSSE 663 Assignment 2</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" type="text/css" href="css.css">
        <script src = "https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"> </script>
        <script src = "javascript.js"></script>
    </head>
    <body>
         <div> 
            <!--UI form -->
            <div id = "group">
                <div id = "display">
                    <h3 id ="loginMessage"></h3>
                </div>
                <br>
                
                Username:<input id ="username" type = "text" name ="txtbox">
                
                <br>
                <br>
                
                Password:<input id ="password" type ="text" name ="txtbox">
               
                <br>
                <br>
                
                <button id ="btn">Submit</button>
            </div>
           
            
            <p id = "show">Login Field </p>
            <p id = "hide">Close Field </p>
           
         </div>
    </body>
</html>