<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


if($_SERVER["REQUEST_METHOD"] == "POST")
{
    //assign vars after formatting to avoid a wrong login with correct 
    //username and password
    $username = trim($_POST["user"]);
    $password = trim($_POST["pass"]);
    
    //specfic message
    $errorMessage = "The username ".$username." or the password ".$password. " is wrong";
    $welcomeMessage = "Welcome ".$username;
   
    //user name or pass word is wrong invovke failure html
    if($password != "1234" || $username != 'Admin')
    {
        include("html.html");
        echo('<message>'.$errorMessage.'</message>');
    }
    
    //username and password is right invoke the html with proper messages
    if($password == "1234" && $username == "Admin")
    {
        include("html.html");
        echo('<message>'.$welcomeMessage.'</message>');
    }
    
    
}
