/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


$(document).ready(function(){
                    
        //hide the show message at first
        $('#group').hide();
        $('#hide').hide();
        $('body').css('background', 'greenyellow');

        //Turn UI pink 
        $('#group').on('mouseleave',function(){
            $('body').css('background','pink');
        });
                    
        //Turn UI red
        $('#group').on('mouseenter', function(){
            $('body').css('background','red'); 
        });
                    
        //show UI
        $('#show').click(function(){
            $('#group').show();
            $('#hide').show();
            $('#show').hide();
        });
                    
        //hide UI
        $('#hide').click(function(){
            $('#group').hide();
            $('#show').show ();
            $('#hide').hide();
            $('body').css('background', 'greenyellow');
        });
        
        
        $('#yes').click(function(){
           $('body').css('background','orange'); 
        });
        
        //submit user info via ajax
        $('#btn').click(function(){
            //pull vars 
            var username = $('#username').val();
            var password = $('#password').val();
            
            //request for username
            $.post("php.php", {user:username,pass:password}).done(function(data){
                $("#loginMessage").html(data);
            }); 
           
        });
        
        //flexslider controlls
        $('.flexslider').flexslider({
             slideshow:true,
             startAt:0,
             slideshowSpeed: 2000,
             initdelay:0,
             randomize:false,
             animation:"slide"
        });
});


//Angular JS for week 3/4.........................................................

var app = angular.module("input", ["ngRoute"]);
app.config(function($routeProvider) {
    $routeProvider
    .when("/element", {
        templateUrl : "singalCustomer.html",
        controller:"customersCtrl"
    })
    .when("/fullList", {
        templateUrl : "fullList.html",
        controller:"customersCtrl" 
    });
  
});


app.controller('customersCtrl', function($scope, $http) {
    
    //for sigle items
    $scope.element = function(num){
        var element_id = num;//num;  
        $http.get("customers.php",{params:{"id":element_id}}).then(function (response) {
            $scope.myData = response.data;
        }
        
        ,function errorCallback(response){
            $scope.e=response.data;
            console.log(e);
            
        });
        
    };
    
    
});
app.controller('customerContorller2', function($scope, $http) {
    
    //for full list of  items
   $scope.list = function(){  
        $http.get("customers.php",{params:{"id":5}}).then(function (response) {
            $scope.Data = response.data;
        }
        
        ,function errorCallback(response){
            $scope.e=response.data;
            console.log(e);
            
        });
        
    };
}); 
//main controller  
app.controller('boxes',function($scope)
{
    //set both vars to 0 each time the page starts
    $scope.like = 0;
    $scope.dislike = 0;
    
    //add 1 for each clike
    $scope.likes = function() 
    {
      $scope.like++;
    };
    
    //add 1 for each dislike 
    $scope.dislikes = function()
    {
      $scope.dislike++;
    };
    
    $scope.users = [
        {name:'Admin', pass:'1234'},
        {name:'User', pass:'2232'},
        {name:'student',pass:'23421'},
        {name:'bob',pass:'1364'},
        {name:'staff', pass:'0302'}
    ];
    
    
});
//..............................................................................