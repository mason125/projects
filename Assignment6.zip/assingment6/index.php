<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<!-- Note to professor Username = Admin, Password: 1234-->
<html>
    <head>
        <title>MSSE 663 Assignment 6</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" type ="text/css" href ="flexslider.css" >

        <link rel="stylesheet" type="text/css" href="css.css">
  
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"> </script>
        <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.4.8/angular.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.4.8/angular-route.js"></script>
        <script src =" jquery.flexslider.js"></script>
        <script src = "javascript.js"></script>
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
        <!-- Optional theme -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
        <!-- Latest compiled and minified JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
         
</head>

    </head>
    <body ng-app="input">
        
         <div class = "container-fluid"> 
            <!--UI form -->
         
            <div ng-view></div>
            <div id = "group">
               
                <div id = "display">
                    <h3 id ="loginMessage"></h3>
                </div>
                <br>  
               
                
                <div ng-controller="boxes">
                    
                 
                                 
                    <strong>Username:</strong><input id ="username" type ="text" name ="txtbox" ng-model="username">
                    <br>
                    <br>
                
                    <strong>Password:</strong><input id ="password" type ="text" name ="txtbox" ng-model="password">
                    <br>
                    <br>
                   
                   <button id ="btn">Submit</button>
                   
                    
                   <br>
                   <br>
                   
                   
                   <!--like/ dislike buttons -->
                   <p>Rate this page </p>
                   <button ng-click="likes()">Like</button>
                   <button ng-click="dislikes()">Dislike</button>
                   
                    
                   <p>{{like}} likes and {{dislike}} dislikes</p>
                  
                   <!--Table for week 4-->
                     <div ng-view></div>
                   <div>
                        <thead>
                        <table class = "table table-striped">
                                <tr>
                                    <th>Username</th>
                                    <th>Password</th>
                                </tr>
                                <tr ng-repeat="array in users | filter:username">
                                    <td>{{array.name}}</td>
                                    <td>{{array.pass}}</td>
                                </tr>
                            </table>
                        </thead>
                   </div>
               
                 </div>
               <a href="#element">View Single Customer</a>
               <br>
               <a href="#fullList">View full list</a>
            </div>
            
            
            
            <p id = "show">Login Field </p>
            <p id = "hide">Close Field </p>
           
         </div>
    </body>
</html>