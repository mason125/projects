<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 * 
 */
if($_SERVER["REQUEST_METHOD"] == "GET")
{
    $id = $_GET[id];
    $customer_array = array();

    $customer1 = array(
        'name' => 'LoneStar',
        'city' => 'Houston'
    );
    
    $customer_array[] = $customer1;

    $customer2 = array(
        'name' => 'SNHU',
        'city' => 'Manchester'
    );

    $customer_array[] = $customer2;
    
    $customer3 = array(
        'name' => "Regis",
        'city' => "Boulder"
    );
    
    $customer_array[] = $customer3;
    //if id is not five return element else return full list
    
    if($id < 5)
        echo json_encode($customer_array[$id]);
      
    else if ($id == 5)
        echo json_encode($customer_array);
    
    else
    {
        http_response_code(401);
        $message = http_response_code()." No data found";
        header('Content-Type: application/json');
        echo json_encode($message);
    }
   
}