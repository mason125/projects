<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>MSSE 663 Assignment 1</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
		
		<!--links-->
        <link rel="stylesheet" type="text/css" href="css.css">
        <script src = "https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"> </script>
        <script script src= "javascript.js"></script> 
    </head>
    <body>
        <div>
            
            <!--UI form -->
            <div id = "group">
                Username:<input type = "text" name ="txtbox"><br><br>
                Password:<input type ="text" name ="txtbox"><br><br>
                <button id ="btn">Submit</button>
            </div>
           
            <p id = "show">Login Field </p>
            <p id = "hide">Close Field </p>
           
        </div>
    </body>
</html>