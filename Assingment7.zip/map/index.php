<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
        <script src = "javascript.js"></script>
        <title></title>
    </head>
    <body>
         <div id="map" style="width:100%;height:400px;"></div>
         <!-- will only work if api link is in the body moved it to the head and will not work!!!-->
        <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCGb2PL05AwjaPXk0GZfbKAoLOWYgYKxkA&callback=myMap"></script>
    </body>
</html>
